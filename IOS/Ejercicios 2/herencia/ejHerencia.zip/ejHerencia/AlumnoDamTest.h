//
//  AlumnoDamTest.h
//  ejHerencia
//
//  Created by A1-IMAC08 on 1/10/21.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AlumnoDamTest : NSObject

@end

NS_ASSUME_NONNULL_END
