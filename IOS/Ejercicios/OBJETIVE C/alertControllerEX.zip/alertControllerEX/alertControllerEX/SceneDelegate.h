//
//  SceneDelegate.h
//  alertControllerEX
//
//  Created by A1-IMAC08 on 22/10/21.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

