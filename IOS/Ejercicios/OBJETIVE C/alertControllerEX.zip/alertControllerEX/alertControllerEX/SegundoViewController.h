//
//  SegundoViewController.h
//  alertControllerEX
//
//  Created by A1-IMAC08 on 26/10/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SegundoViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *saludo;

@property NSString *saludoStirng;

@property (weak, nonatomic) IBOutlet UILabel *clase;

@property NSString *claseStirng;

@property (weak, nonatomic) IBOutlet UIButton *back;

@end

NS_ASSUME_NONNULL_END
