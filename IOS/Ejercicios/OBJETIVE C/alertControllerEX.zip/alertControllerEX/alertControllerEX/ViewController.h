//
//  ViewController.h
//  alertControllerEX
//
//  Created by A1-IMAC08 on 22/10/21.
//

#import <UIKit/UIKit.h>
#import "SegundoViewController.h"

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *userTxt;

@property (weak, nonatomic) IBOutlet UITextField *passTxt;

@property (weak, nonatomic) IBOutlet UIButton *soyAlumnoButton;

@property (weak, nonatomic) IBOutlet UIButton *loginButton;



@end

